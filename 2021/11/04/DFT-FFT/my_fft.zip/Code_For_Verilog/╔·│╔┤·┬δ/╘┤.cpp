#include<iostream>
#include <fstream>
#include <cmath>
using namespace std;

int main()
{
	int point, n, m, k, factor, a, b, c, d;
	ofstream outfile_1, outfile_2, outfile_3, outfile_4, outfile_5, outfile_6, outfile_7, outfile_assign, outfile_tb, outfile_matlab;
	cout << "�˳�������128��fft�������" << endl;
	point = 128;
	m = log(point) / log(2);
	k = point / 2;
	cout << "fft������" << m << "��" << "ÿһ����Ҫ" << k << "�����ε�Ԫ" << "��" << (k * m) << "�����ε�Ԫ" << endl;
	outfile_1 << "fft������" << m << "��" << "ÿһ����Ҫ" << k << "�����ε�Ԫ" << "��" << (k * m) << "�����ε�Ԫ" << endl;
	outfile_1.open("code_state_1.txt");
	//--------------------------------------------------------stage_1--------------------------------------------------------
		for (size_t j = 0; j < point; j++)
		{
			m = 0;
			outfile_1 << endl << "/*-------���ε�Ԫ------(1," << j + 1 << ")*/" << endl;
			outfile_1 << "butterfly	stage_1"<< "_unit_" << j + 1 << "(" << endl;
			outfile_1 << ".clk         (clk)           ," << endl;
			outfile_1 << ".rstn        (rstn)          ," << endl;
			outfile_1 << ".en          (en_connect[" << m << "][" << j << "]) ," << endl;
			outfile_1 << "//��������" << endl;
			outfile_1 << ".xp_real     (xm_real[" << m << "][" << (2 * j) << "])," << endl;
			outfile_1 << ".xp_imag     (xm_imag[" << m << "][" << (2 * j) << "])," << endl;
			outfile_1 << ".xq_real     (xm_real[" << m << "][" << (2 * j + 1) << "])," << endl;
			outfile_1 << ".xq_imag     (xm_imag[" << m << "][" << (2 * j + 1) << "])," << endl;
			outfile_1 << ".factor_real (factor_real[0])," << endl;
			outfile_1 << ".factor_imag (factor_imag[0])," << endl;
			outfile_1 << "//�������" << endl;
			outfile_1 << ".valid       (en_connect[" << (m + 1) << "][" << j << "]) ," << endl;
			outfile_1 << ".yp_real     (xm_real[" << (m + 1) << "][" << (2 * j) << "])," << endl;
			outfile_1 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (2 * j) << "])," << endl;
			outfile_1 << ".yq_real     (xm_real[" << (m + 1) << "][" << (2 * j + 1) << "])," << endl;
			outfile_1 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (2 * j + 1) << "])" << endl;
			outfile_1 << ");" << endl;
		}
		cout << "code_state_1.txt-----done" << endl;
		outfile_1.close();

		//--------------------------------------------------------stage_2--------------------------------------------------------
		n = 0; a = 0, b = 0;
		outfile_2.open("code_state_2.txt");
		for (size_t j = 0; j < k*2; j=j+4)
		{
			m = 1;
			a = j;
			for (size_t i = 0; i < 2; i++)
			{
				n++;
				if (i == 0)
				{
					factor = 0;
				}
				else
				{
					factor = 32;
				}
				outfile_2 << endl << "/*-------���ε�Ԫ------(2," << n << ")*/" << endl;
				outfile_2 << "butterfly	stage_2" << "_unit_" << n << "(" << endl;
				outfile_2 << ".clk         (clk)           ," << endl;
				outfile_2 << ".rstn        (rstn)          ," << endl;
				outfile_2 << ".en          (en_connect[1][" << b << "] && en_connect[1][" << b + 1 << "] ? 1'b1 : 1'b0)," << endl;
				outfile_2 << "//��������" << endl;
				outfile_2 << ".xp_real     (xm_real[" << m << "][" << (a) << "])," << endl;
				outfile_2 << ".xp_imag     (xm_imag[" << m << "][" << (a) << "])," << endl;
				outfile_2 << ".xq_real     (xm_real[" << m << "][" << (a + 2) << "])," << endl;
				outfile_2 << ".xq_imag     (xm_imag[" << m << "][" << (a + 2) << "])," << endl;
				outfile_2 << ".factor_real (factor_real[" << factor << "])," << endl;
				outfile_2 << ".factor_imag (factor_imag[" << factor << "])," << endl;
				outfile_2 << "//�������" << endl;
				outfile_2 << ".valid       (en_connect[" << (m + 1) << "][" << (n - 1) << "]) ," << endl;
				outfile_2 << ".yp_real     (xm_real[" << (m + 1) << "][" << (a) << "])," << endl;
				outfile_2 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (a) << "])," << endl;
				outfile_2 << ".yq_real     (xm_real[" << (m + 1) << "][" << (a + 2) << "])," << endl;
				outfile_2 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (a + 2) << "])" << endl;
				outfile_2 << ");" << endl;
				a++;
			}
			b += 2;
		}
		cout << "code_state_2.txt-----done" << endl;
		outfile_2.close();
		//--------------------------------------------------------stage_3--------------------------------------------------------
		n = 0; a = 0, b = 0, c = 0, d = 0;
		outfile_3.open("code_state_3.txt");
		for (size_t j = 0; j < k*2; j = j + 8)
		{
			m = 2;
			a = j;
			b = j / 2;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				c = b;
				for (size_t x = 0; x < 2; x++)
				{
					n++;
					factor = 16 * d;
					outfile_3 << endl << "/*-------���ε�Ԫ------(3," << n << ")*/" << endl;
					outfile_3 << "butterfly	stage_3" << "_unit_" << n << "(" << endl;
					outfile_3 << ".clk         (clk)           ," << endl;
					outfile_3 << ".rstn        (rstn)          ," << endl;
					outfile_3 << ".en          (en_connect[2][" << c << "] && en_connect[2][" << c + 2 << "] ? 1'b1 : 1'b0)," << endl;
					outfile_3 << "//��������" << endl;
					outfile_3 << ".xp_real     (xm_real[" << m << "][" << (a) << "])," << endl;
					outfile_3 << ".xp_imag     (xm_imag[" << m << "][" << (a) << "])," << endl;
					outfile_3 << ".xq_real     (xm_real[" << m << "][" << (a + 4) << "])," << endl;
					outfile_3 << ".xq_imag     (xm_imag[" << m << "][" << (a + 4) << "])," << endl;
					outfile_3 << ".factor_real (factor_real[" << factor << "])," << endl;
					outfile_3 << ".factor_imag (factor_imag[" << factor << "])," << endl;
					outfile_3 << "//�������" << endl;
					outfile_3 << ".valid       (en_connect[" << (m + 1) << "][" << (n - 1) << "]) ," << endl;
					outfile_3 << ".yp_real     (xm_real[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_3 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_3 << ".yq_real     (xm_real[" << (m + 1) << "][" << (a + 4) << "])," << endl;
					outfile_3 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (a + 4) << "])" << endl;
					outfile_3 << ");" << endl;
					a++;
					c++;
					d++;
				}
			}
		}
		cout << "code_state_3.txt-----done" << endl;
		outfile_3.close();
		//--------------------------------------------------------stage_4--------------------------------------------------------
		n = 0; a = 0, b = 0, c = 0, d = 0;
		outfile_4.open("code_state_4.txt");
		for (size_t j = 0; j < k * 2; j = j + 16)
		{
			m = 3;
			a = j;
			b = j / 2;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				c = b;
				for (size_t x = 0; x < 4; x++)
				{
					n++;
					factor = 8 * d;
					outfile_4 << endl << "/*-------���ε�Ԫ------(4," << n << ")*/" << endl;
					outfile_4 << "butterfly	stage_4" << "_unit_" << n << "(" << endl;
					outfile_4 << ".clk         (clk)           ," << endl;
					outfile_4 << ".rstn        (rstn)          ," << endl;
					outfile_4 << ".en          (en_connect[3][" << c << "] && en_connect[3][" << c + 4 << "] ? 1'b1 : 1'b0)," << endl;
					outfile_4 << "//��������" << endl;
					outfile_4 << ".xp_real     (xm_real[" << m << "][" << (a) << "])," << endl;
					outfile_4 << ".xp_imag     (xm_imag[" << m << "][" << (a) << "])," << endl;
					outfile_4 << ".xq_real     (xm_real[" << m << "][" << (a + 8) << "])," << endl;
					outfile_4 << ".xq_imag     (xm_imag[" << m << "][" << (a + 8) << "])," << endl;
					outfile_4 << ".factor_real (factor_real[" << factor << "])," << endl;
					outfile_4 << ".factor_imag (factor_imag[" << factor << "])," << endl;
					outfile_4 << "//�������" << endl;
					outfile_4 << ".valid       (en_connect[" << (m + 1) << "][" << (n - 1) << "]) ," << endl;
					outfile_4 << ".yp_real     (xm_real[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_4 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_4 << ".yq_real     (xm_real[" << (m + 1) << "][" << (a + 8) << "])," << endl;
					outfile_4 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (a + 8) << "])" << endl;
					outfile_4 << ");" << endl;
					a++;
					c++;
					d++;
				}
			}
		}
		cout << "code_state_4.txt-----done" << endl;
		outfile_4.close();
		//--------------------------------------------------------stage_5--------------------------------------------------------
		n = 0; a = 0, b = 0, c = 0, d = 0;
		outfile_5.open("code_state_5.txt");
		for (size_t j = 0; j < k * 2; j = j + 32)
		{
			m = 4;
			a = j;
			b = j / 2;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				c = b;
				for (size_t x = 0; x < 8; x++)
				{
					n++;
					factor = 4 * d;
					outfile_5 << endl << "/*-------���ε�Ԫ------(5," << n << ")*/" << endl;
					outfile_5 << "butterfly	stage_5" << "_unit_" << n << "(" << endl;
					outfile_5 << ".clk         (clk)           ," << endl;
					outfile_5 << ".rstn        (rstn)          ," << endl;
					outfile_5 << ".en          (en_connect[4][" << c << "] && en_connect[4][" << c + 8 << "] ? 1'b1 : 1'b0)," << endl;
					outfile_5 << "//��������" << endl;
					outfile_5 << ".xp_real     (xm_real[" << m << "][" << (a) << "])," << endl;
					outfile_5 << ".xp_imag     (xm_imag[" << m << "][" << (a) << "])," << endl;
					outfile_5 << ".xq_real     (xm_real[" << m << "][" << (a + 16) << "])," << endl;
					outfile_5 << ".xq_imag     (xm_imag[" << m << "][" << (a + 16) << "])," << endl;
					outfile_5 << ".factor_real (factor_real[" << factor << "])," << endl;
					outfile_5 << ".factor_imag (factor_imag[" << factor << "])," << endl;
					outfile_5 << "//�������" << endl;
					outfile_5 << ".valid       (en_connect[" << (m + 1) << "][" << (n - 1) << "]) ," << endl;
					outfile_5 << ".yp_real     (xm_real[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_5 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_5 << ".yq_real     (xm_real[" << (m + 1) << "][" << (a + 16) << "])," << endl;
					outfile_5 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (a + 16) << "])" << endl;
					outfile_5 << ");" << endl;
					a++;
					c++;
					d++;
				}
			}
		}
		cout << "code_state_5.txt-----done" << endl;
		outfile_5.close();
		//--------------------------------------------------------stage_6--------------------------------------------------------
		n = 0; a = 0, b = 0, c = 0, d = 0;
		outfile_6.open("code_state_6.txt");
		for (size_t j = 0; j < k * 2; j = j + 64)
		{
			m = 5;
			a = j;
			d = 0;
			b = j / 2;
			for (size_t i = 0; i < 2; i++)
			{
				c = b;
				for (size_t x = 0; x < 16; x++)
				{
					n++;
					factor = 2 * d;
					outfile_6 << endl << "/*-------���ε�Ԫ------(6," << n << ")*/" << endl;
					outfile_6 << "butterfly	stage_6" << "_unit_" << n << "(" << endl;
					outfile_6 << ".clk         (clk)           ," << endl;
					outfile_6 << ".rstn        (rstn)          ," << endl;
					outfile_6 << ".en          (en_connect[5][" << c << "] && en_connect[5][" << c + 16 << "] ? 1'b1 : 1'b0)," << endl;
					outfile_6 << "//��������" << endl;
					outfile_6 << ".xp_real     (xm_real[" << m << "][" << (a) << "])," << endl;
					outfile_6 << ".xp_imag     (xm_imag[" << m << "][" << (a) << "])," << endl;
					outfile_6 << ".xq_real     (xm_real[" << m << "][" << (a + 32) << "])," << endl;
					outfile_6 << ".xq_imag     (xm_imag[" << m << "][" << (a + 32) << "])," << endl;
					outfile_6 << ".factor_real (factor_real[" << factor << "])," << endl;
					outfile_6 << ".factor_imag (factor_imag[" << factor << "])," << endl;
					outfile_6 << "//�������" << endl;
					outfile_6 << ".valid       (en_connect[" << (m + 1) << "][" << (n-1) << "]) ," << endl;
					outfile_6 << ".yp_real     (xm_real[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_6 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_6 << ".yq_real     (xm_real[" << (m + 1) << "][" << (a + 32) << "])," << endl;
					outfile_6 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (a + 32) << "])" << endl;
					outfile_6 << ");" << endl;
					a++;
					c++;
					d++;
				}
			}
		}
		cout << "code_state_6.txt-----done" << endl;
		outfile_6.close();
		//--------------------------------------------------------stage_7--------------------------------------------------------
		n = 0; a = 0, b = 0, c = 0, d = 0;
		outfile_7.open("code_state_7.txt");
		for (size_t j = 0; j < k * 2; j = j + 128)
		{
			m = 6;
			a = j;
			b = j / 2;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				c = b;
				for (size_t x = 0; x < 32; x++)
				{
					n++;
					factor = 1 * d;
					outfile_7 << endl << "/*-------���ε�Ԫ------(7," << n << ")*/" << endl;
					outfile_7 << "butterfly	stage_7" << "_unit_" << n << "(" << endl;
					outfile_7 << ".clk         (clk)           ," << endl;
					outfile_7 << ".rstn        (rstn)          ," << endl;
					outfile_7 << ".en          (en_connect[6][" << c << "] && en_connect[6][" << c + 32 << "] ? 1'b1 : 1'b0)," << endl;
					outfile_7 << "//��������" << endl;
					outfile_7 << ".xp_real     (xm_real[" << m << "][" << (a) << "])," << endl;
					outfile_7 << ".xp_imag     (xm_imag[" << m << "][" << (a) << "])," << endl;
					outfile_7 << ".xq_real     (xm_real[" << m << "][" << (a + 64) << "])," << endl;
					outfile_7 << ".xq_imag     (xm_imag[" << m << "][" << (a + 64) << "])," << endl;
					outfile_7 << ".factor_real (factor_real[" << factor << "])," << endl;
					outfile_7 << ".factor_imag (factor_imag[" << factor << "])," << endl;
					outfile_7 << "//�������" << endl;
					outfile_7 << ".valid       (en_connect[" << (m + 1) << "][" << (n - 1) << "]) ," << endl;
					outfile_7 << ".yp_real     (xm_real[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_7 << ".yp_imag     (xm_imag[" << (m + 1) << "][" << (a) << "])," << endl;
					outfile_7 << ".yq_real     (xm_real[" << (m + 1) << "][" << (a + 64) << "])," << endl;
					outfile_7 << ".yq_imag     (xm_imag[" << (m + 1) << "][" << (a + 64) << "])" << endl;
					outfile_7 << ");" << endl;
					a++;
					c++;
					d++;
				}
			}
		}
		cout << "code_state_7.txt-----done" << endl;
		outfile_7.close();
		//--------------------------------------------------------assign--------------------------------------------------------
		outfile_assign.open("assign.txt");
		for (size_t i = 0; i < point; i++)
		{
			outfile_assign << "assign     y" << i << "_real = xm_real[7][" << (i) << "];" << endl;
			outfile_assign << "assign     y" << i << "_imag = xm_imag[7][" << (i) << "];" << endl;
		}
		cout << "assign.txt-----done" << endl;
		outfile_assign.close();
		//--------------------------------------------------------tb--------------------------------------------------------
		n = 0;
		outfile_tb.open("tb.txt");
		for (size_t i = 0; i < point; i++)
		{
			outfile_tb << ".x" << i << "_real		(x" << (i) << "_real)," << endl;
			outfile_tb << ".x" << i << "_imag		(x" << (i) << "_imag)," << endl;
		}
		for (size_t i = 0; i < point; i++)
		{
			n = i * 3 - 100;
			if (n<=0)
			{
				n = 0 - n;
			}
			outfile_tb << "x" << i << "_real	=	" << "24'd" << (n) << ";" << endl;
			outfile_tb << "x" << i << "_imag	=	" << "24'd" << (i * 0) << ";" << endl;
		}
		cout << "tb.txt-----done" << endl;
		outfile_tb.close();
		//--------------------------------------------------------matlab--------------------------------------------------------
		outfile_matlab.open("matlab_step128.txt");
		outfile_matlab << "%% -------------------stage1-------------------" << endl;
		for (size_t i = 0; i < point; i=i+2)
		{
			outfile_matlab << "%%------------unit_" << i << "------------" << endl;
			outfile_matlab << "xm1(" << (i + 1) << ") = xm0(" << (i + 1) << ") + xm0(" << (i + 2) << ") * Wnr(1);" << endl;
			outfile_matlab << "xm1(" << (i + 2) << ") = xm0(" << (i + 1) << ") - xm0(" << (i + 2) << ") * Wnr(1);" << endl;
		}
		outfile_matlab << "floor(xm1(:))" << endl;

		outfile_matlab << "%% -------------------stage2-------------------" << endl;
		n = 0; a = 0, b = 0;
		for (size_t j = 0; j < k * 2; j = j + 4)
		{
			a = j;
			for (size_t i = 0; i < 2; i++)
			{
				n++;
				if (i == 0)
				{
					factor = 0;
				}
				else
				{
					factor = 32;
				}
				outfile_matlab << "%%------------unit_" << n << "------------" << endl;
				outfile_matlab << "xm2(" << (a + 1) << ") = xm1(" << (a + 1) << ") + xm1(" << (a + 2 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
				outfile_matlab << "xm2(" << (a + 2 + 1) << ") = xm1(" << (a + 1) << ") - xm1(" << (a + 2 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
				a++;
			}
			b += 2;
		}
		outfile_matlab << "floor(xm2(:))" << endl;

		outfile_matlab << "%% -------------------stage3-------------------" << endl;
		n = 0; a = 0, b = 0, c = 0, d = 0;
		for (size_t j = 0; j < point; j = j + 8)
		{
			a = j;
			b = j / 2;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				c = b;
				for (size_t x = 0; x < 2; x++)
				{
					n++;
					factor = 16 * d;
					outfile_matlab << "%%------------unit_" << n << "------------" << endl;
					outfile_matlab << "xm3(" << (a + 1) << ") = xm2(" << (a + 1) << ") + xm2(" << (a + 4 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					outfile_matlab << "xm3(" << (a + 4 + 1) << ") = xm2(" << (a + 1) << ") - xm2(" << (a + 4 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					a++;
					c++;
					d++;
				}
			}
		}
		outfile_matlab << "floor(xm3(:))" << endl;

		outfile_matlab << "%% -------------------stage4-------------------" << endl;
		n = 0; a = 0, b = 0, c = 0, d = 0;
		for (size_t j = 0; j < point; j = j + 16)
		{
			a = j;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				for (size_t x = 0; x < 4; x++)
				{
					n++;
					factor = 8 * d;
					outfile_matlab << "%%------------unit_" << n << "------------" << endl;
					outfile_matlab << "xm4(" << (a + 1) << ") = xm3(" << (a + 1) << ") + xm3(" << (a + 8 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					outfile_matlab << "xm4(" << (a + 8 + 1) << ") = xm3(" << (a + 1) << ") - xm3(" << (a + 8 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					a++;
					d++;
				}
			}
		}
		outfile_matlab << "floor(xm4(:))" << endl;

		outfile_matlab << "%% -------------------stage5-------------------" << endl;
		n = 0; a = 0, b = 0, c = 0, d = 0;
		for (size_t j = 0; j < point; j = j + 32)
		{
			a = j;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				for (size_t x = 0; x < 8; x++)
				{
					n++;
					factor = 4 * d;
					outfile_matlab << "%%------------unit_" << n << "------------" << endl;
					outfile_matlab << "xm5(" << (a + 1) << ") = xm4(" << (a + 1) << ") + xm4(" << (a + 16 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					outfile_matlab << "xm5(" << (a + 16 + 1) << ") = xm4(" << (a + 1) << ") - xm4(" << (a + 16 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					a++;
					d++;
				}
			}
		}
		outfile_matlab << "floor(xm5(:))" << endl;

		outfile_matlab << "%% -------------------stage6-------------------" << endl;
		n = 0; a = 0, b = 0, c = 0, d = 0;
		for (size_t j = 0; j < point; j = j + 64)
		{
			a = j;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				for (size_t x = 0; x < 16; x++)
				{
					n++;
					factor = 2 * d;
					outfile_matlab << "%%------------unit_" << n << "------------" << endl;
					outfile_matlab << "xm6(" << (a + 1) << ") = xm5(" << (a + 1) << ") + xm5(" << (a + 32 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					outfile_matlab << "xm6(" << (a + 32 + 1) << ") = xm5(" << (a + 1) << ") - xm5(" << (a + 32 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					a++;
					d++;
				}
			}
		}
		outfile_matlab << "floor(xm6(:))" << endl;

		outfile_matlab << "%% -------------------stage7-------------------" << endl;
		n = 0; a = 0, b = 0, c = 0, d = 0;
		for (size_t j = 0; j < point; j = j + 128)
		{
			a = j;
			d = 0;
			for (size_t i = 0; i < 2; i++)
			{
				for (size_t x = 0; x < 32; x++)
				{
					n++;
					factor = 1 * d;
					outfile_matlab << "%%------------unit_" << n << "------------" << endl;
					outfile_matlab << "xm7(" << (a + 1) << ") = xm6(" << (a + 1) << ") + xm6(" << (a + 64 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					outfile_matlab << "xm7(" << (a + 64 + 1) << ") = xm6(" << (a + 1) << ") - xm6(" << (a + 64 + 1) << ") * Wnr(" << (factor + 1) << ");" << endl;
					a++;
					d++;
				}
			}
		}
		outfile_matlab << "floor(xm7(:))" << endl;

		outfile_matlab.close();
		cout << "matlab_step128.txt-----done" << endl;
		system("pause");
	return 0;
}