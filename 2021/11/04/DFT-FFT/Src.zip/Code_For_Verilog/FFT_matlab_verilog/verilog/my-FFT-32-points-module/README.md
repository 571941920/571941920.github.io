# FFT_32-points-hardware-module

* Fast Fourier transform

* Verilog HDL implementation

* 32 points

* Radix 2 butterfly

* Single path delay feedback processor

# Our FFT-32 source code is just small modification from FFT-32 of Mr Jason:

* https://github.com/jasonlin316/A-Single-Path-Delay-32-Point-FFT-Processor

# FFT processor for FMCW radar signal processing

## The Magnitude Calculation Unit: Approximate

## The Phase Calculation Unit: CORDIC 

## very efficient for FMCW radar signal processing and can be used for other applicationssuch as wireless communication with orthogonal frequency division multiplexing (OFDM)modulation and voice recognition systems with frequency analysis, which requires a highSQNR and the abovementioned special functions.

## In future work, we will implement a radar signal processor that includes the proposedFFT processor in VLSI. It and will be expected to find wide use in automobiles, drones andwearable devices that require low-cost, llow-power implementation. 

(PDF) FPGA Implementation of an Efficient FFT Processor for FMCW Radar Signal Processing. Available from: 

https://www.researchgate.net/publication/354891666_FPGA_Implementation_of_an_Efficient_FFT_Processor_for_FMCW_Radar_Signal_Processing

# mducng
