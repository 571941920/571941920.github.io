clc;
clear;
% fm = get_fimath();
Wnk = Wnk_gen(128);
Wnk_fi = fi(Wnk,1,16,8);
N=32;A0=1;
i=1:N;
x=A0 * (sin(2*pi*i/25 + 3*pi/5).*(cos(2*pi* i * 0.4 )));
A = sin(2*pi*i/25 + 3*pi/5)';
B = cos(2*pi* i * 0.4 )';
fix_A = A.*2^4;
fix_B = B.*2^4;
% x1 = fi(x,1,17,8,fm)
% y = abs(my_fft_ifft(x1,1));
% a = abs(fft(x,N));%���и���Ҷ�任��÷�����
% subplot(2,1,1);plot(i,a);title('fft');
% subplot(2,1,2);plot(i,y);title('my-fft')
qpath = quantizer('fixed','round','saturate',[17,8]);%1λ����λ��8λС��
fix_x = quantize(qpath,x);
fix_x = fix_x'.*2^8;%��4λС���������
%% 
clc;
clear;
close all;

a = fi(0.5,1,17,8)
a.bin
b = fi(3,1,17,8)
b.bin
c = a*b
c.bin
%% 
clc;
clear;
close all;
c =[   
0
260
34
618
221
622
512
366
665
106
 477
 4
 -1
 -5
 -478
 -107
 -666
 -367
 -513
 -623
 -222
 -619
 -35
 -261
 -1
 260
 34
 618
 221
 622
 511
 0];
b = [320
111
-168
-276
-151
82
244
213
1
-238
-286
-63
250
343
93
-268
-371
-100
268
360
98
-238
-323
-111
172
277
147
-88
-246
-210
3
236];
a = [10, 20, 30, 40, 10, 20 ,30 ,40];
a_r = rader(a,8)
a1 = [-40 -40 ];
c_fft = fft(a,8)
c_fft = c_fft.'
%% 
clc
clear
i=1:128;
x=0:127;
y(i)=x;
x = [11+2i, 21+5i, 61+3i, 41+6i, 33+4i, 21+8i ,36+11i ,41+7i]
x_fft = fft(x,128)
a = (0:127);
%y(i)=rader(y,127);
v = bitrevorder(a)
%% 
dec = zeros(1,64);
for i = 1 : 64
    dec(i) = bin2dec(ffto(i,:));
    if(ffto(i,1) == '1')
        dec(i) = dec(i) - 2^17
    end
end
%% 
a = Wnk_gen(8)
%%
clc;

val = 1;   %�仯�˻�ֵ
a   = 2;   %�㶨�˻�ֵ

mul_val = abs(val);   %�仯�˻�ֵ
mul_a   = abs(a);   %�㶨�˻�ֵ

%����ֵ��λ��ռ�ü���
size_val = ceil(log2(mul_val));

%����ֵ��λ��ռ�ü���
size_a = ceil(log2(mul_a));

%����һ������λ
size_val = size_val + 1;
size_a = size_a + 1;

%����ֵ��λ��ռ�ü���
% fprintf("size_a = %d\n", size_a);
% fprintf("size_val = %d\n", size_val);

%ת��Ϊ������
B_mul_val  = dec2bin(val+((val)<0)*2^size_val,size_val);
B_mul_a    = dec2bin(a  +((a)<0)*2^size_a  ,size_a  );
B_mul_a_abs= dec2bin(abs(a),(size_a-1));

%�˻���λ��
size_mul_all = size_a + size_val;

%��ӡ����
flag = 0;

if(B_mul_a(1) == "1")
    fprintf("assign mult_tem = {\n");
else
    fprintf("assign mult_solution = {\n");
end

for i=1:1:(size_a - 1)
    if(B_mul_a_abs(size_a-1) == "1" && i == 1)
        fprintf(" {%d{B_mul_val[%d]}, B_mul_val}\n",size_a-i,size_val);
        flag = 1;
    else
        if(B_mul_a_abs(size_a-i) == "1")
             if(flag == 0)
                fprintf(" {%d{B_mul_val[%d]}, B_mul_val, %d'b0}\n",size_a-i, size_val, i-1);
                flag = 1;
             else
                fprintf("+{%d{B_mul_val[%d]}, B_mul_val, %d'b0}\n",size_a-i, size_val, i-1);
             end
        end
    end   
end

fprintf("};\n");

if(B_mul_a(1) == "1")
    fprintf("assign mult_solution = ~mult_tem + 1'b1;\n");
end

fprintf("\n");
flag = 0;
%%
i=0:1:127;
x=abs(i*3-100);
a=[100 92];
m=fft(a,2);
m=m.'