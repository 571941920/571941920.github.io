function yn = my_fft_ifft(xn,sign)
x=real(xn);
y=imag(xn);
n=length(xn);

j=1;
for i=1:n
    m=i;
    j=2*j;
    if j==n
        break;
    end
end
j=1;
n1=n-1;
for i=1:n1
    if i<j
        tr=x(j);
        ti=y(j);
        x(j)=x(i);
        y(j)=y(i);
        x(i)=tr;
        y(i)=ti;
    end
    k=n/2;
    while k<j
        j=j-k;
        k=k/2;
    end
    j=j+k;
end
n1=1;
for l=1:m
    n1=2*n1;
    n2=n1/2;
    e=pi/n2;
    c=1.0;
    s=0.0;
    c1=cos(e);
    s1=-sign*sin(e);
    for j=1:n2
        i=j;
        while i<n
            k=i+n2;
            tr=c*x(k)-s*y(k);
            ti=c*y(k)+s*x(k);
            x(k)=x(i)-tr;
            y(k)=y(i)-ti;
            x(i)=x(i)+tr;
            y(i)=y(i)+ti;
            i=i+n1;
        end
        t=c;
        c=c*c1-s*s1;
        s=t*s1+s*c1;
        j=j+1;
    end
end
if sign==-1
    for i=1:n
        x(i)=x(i)/n;
        y(i)=y(i)/n;
    end
end
yn=x+1i*y;
end