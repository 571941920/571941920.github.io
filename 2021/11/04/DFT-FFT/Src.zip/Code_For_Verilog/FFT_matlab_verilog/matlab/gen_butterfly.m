%% 
clc
clear
N = 8;
M = log2(N);%求是2的几次幂
K = N / 2;
%%
x = 0;
fprintf("butterfly  u_butter(\n");
for i = 0 : M-1
    for j = 0 : K-1 
        x = x + 1;
        str1 = 	".clk   (clk) ,\n.rstn  (rstn) ,\n.en   (en_connect[%d]) ,\n//输入数据\n";
        str2 = ".xp_real    (xm_real[%d][%d]),\n.xp_imag  (xm_imag[%d][%d]),\n.xq_real  (xm_real[%d][%d]),\n.xq_imag     (xm_imag[0][3]),\n";
        fprintf(str1,i*4+j);
        fprintf(str2,i,);
    end
end
%% 
