clc;
clear;
N = 1024;
M = log2(N);
bit = 1:N;
for i=1:N
    j=0;
    for k=1:M/2
        m = 1;
        n = pow(M-1);
        m = bitshift(m,k);
        n = bitshift(n,-k);
        F0 = bitand(i,n);
        F1 = bitand(i,m);
        if(F0)
            j = bitor(j,m);
        end
        if(F1)
            j = bitor(j,n);
        end
    end
    if(i<j)
        temp = 
        