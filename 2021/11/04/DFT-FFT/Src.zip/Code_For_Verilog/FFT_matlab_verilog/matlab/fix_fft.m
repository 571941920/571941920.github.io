%% -----------------------------
clc;
clear;
close all;

N = 32;
fm = get_fimath();
i = 1 : N;
x = 1 * (sin(2*pi*i/50 + 3*pi/5)+cos(2*pi* i * 0.4 ));
M = log2(N);%求fft级数
y = rader(x,N);% 求序号的倒序
fix_y = fi(y,1,17,8,fm);
WN = exp(-1i*2*pi/N);
fix_WN = fi(WN,1,17,8,fm);%旋转因子8位小数位，1位符号位，8位整数位
%% 测试数据大小用
m = 0;
n = 0;
WN1 = exp(-1i*2*pi/N);
A = zeros(M,(N/2)*(log2(N)));
temp = zeros(M,(N/2)*(log2(N)));
out = zeros(1,N);
result = zeros(1,N);
%% -----------------------------
for L=1:M
    m = m + 1;
    B=bitshift(1,L-1);%第L级中，每个蝶形的两个输入数据相距B个点，每级有B个不同的旋转因子
    for J = 0:B-1 % J代表了不同的旋转因子
        p = bitshift(J,M-L);% 旋转因子增量  
        WNp = WN.^p;
        fix_WNp = fix_WN.^p;
        for k = J+1:2^L:N % 本次蝶形运算的跨越间隔为2^L 
            n = n + 1;
            kp = k + B; % 蝶形运算的两个因子对应单元下标的关系
%             temp(m,n) = y(kp) .* WNp; % N/2 * log2N次乘法
            A(m,n) = fix_y(kp) .* fix_WNp;
            t = fix_y(kp) .* fix_WNp ;% 蝶形运算的乘积项   
            fix_y(kp) = fix_y(k) - t ; % 蝶形运算， 先进行减法运算，然后进行加法运算，否则要使用中间变量来传递y(k)
            fix_y(k) = fix_y(k) + t ;% 蝶形运算
        end 
    end 
end
A = A';
%% -----------------------------
y_o = abs(fix_y);
y1=abs(fft(x)); %结果对比
subplot(2,1,1);plot(i,y1);title('fft');
subplot(2,1,2);plot(i,y_o);title('my-fft')
%% 
fix_y = fix_y';
fix_y_bin = fix_y.bin