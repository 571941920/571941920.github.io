function [outputArg1] = Wnk_gen(inputArg1)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
N = inputArg1;
Wnr_re = zeros((N/2)-1,1);
Wnr_im = zeros((N/2)-1,1);
Wnk = zeros(N/2,N/2);
for r = 0:(N/2)-1
    Wnr_factor  = cos(pi/4*r) - 1i*sin(pi/4*r) ;
    Wnr_real    = real(Wnr_factor) ;
    Wnr_imag    = imag(Wnr_factor);
    
%     Wnr(2*r+1,:)  =  dec2hex(Wnr_real) 
%     Wnr(2*r+2,:)  =  dec2hex(Wnr_imag)
    Wnr_re(r+1,:)  =  (Wnr_real);
    Wnr_im(r+1,:)  =  (Wnr_imag);
    Wnk = [Wnr_re,Wnr_im];
%     Wnk = dec2hex(Wnk);
end
outputArg1 = Wnk;
end

