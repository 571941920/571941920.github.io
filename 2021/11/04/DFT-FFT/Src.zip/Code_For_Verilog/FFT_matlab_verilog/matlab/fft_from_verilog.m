%% -----------------------------
clc;
clear;
close all;
N = 32;
num_bit = 24;
fm = get_fimath();

TWFa         =  exp(-1i*2*pi/N);%计算旋转因子
TWFa =  fi(TWFa,1,24,8,fm);

i = 1 : N;
x = 1 * (sin(2*pi*i/25 + 3*pi/5)+cos(2*pi* i * 0.4 ));%输入的信号x 
x = floor(x.*2^8);
x1 = [0,260,34,618,221,622,512,366,665,106,477,4,-1,...
    -5,-478,-107,-666,-367,-513,-623,-222,-619,-35,...
    -261,-1,260,34,618,221,622,511,0];%根据fpga代码，输入的12位数据，扩展4位符号位，后面加上8'b0，总共24位；
y1 = fi(x1./2^6,1,11,6);
b_y1 = y1.bin

din_r_reg = repmat('0',N,num_bit);%din_r_reg初始化
dec = zeros(1,N);
high_4bit = zeros(1,4);%高4位初值设为[0 0 0 0]
low_8bit = zeros(1,8);%低八位[0 0 0 0 0 0 0 0]
high_15bit = zeros(1,15);

% % x_in = fi(x,1,24,8,fm);
%十进制---二进制
for i = 1 : N
    bit = bitget(x(i),12:-1:1,'int16');%用int16 取12位。
    high_4bit = bit(1) + zeros(1,4);%符号位加上高4位，相当于前四位补符号位
    din_r = [high_4bit bit low_8bit];%拼接位24位
    din_r_reg(i,:) = num2str(din_r,'%d');        
end
% %二进制---十进制
for i = 1 : N
    dec(i) = bin2dec(din_r_reg(i,:));
    if(din_r_reg(i,1) == '1')
        dec(i) = dec(i) - 2^24;
    end
end
M = log2(N);%求是2的几次幂
y = rader(x,N);% 求序号的倒序
WN = exp(-1i*2*pi/N);
WN = floor(WN.*2^8);
fix_WN = WN./2^8;

WN_r_bit = num2str(bitget(real(WN),9:-1:1,'int16'),'%d');
WN_i_bit = num2str(bitget(imag(WN),9:-1:1,'int16'),'%d');

high_15bit = WN_r_bit(1) + zeros(1,15);
WN_r_reg = [high_15bit WN_r_bit];
WN_r_reg(1,:) = num2str(WN_r_reg,'%d'); %24'b 00000000_00000000_11111011

high_15bit = WN_i_bit(1) + zeros(1,15);
WN_i_reg = [high_15bit WN_r_bit];
WN_i_reg(1,:) = num2str(WN_i_reg,'%d'); %24'b 11111111_11111111_11001110;
% WN = fi(WN,1,24,8,fm);%旋转因子8位小数位，1位符号位，8位整数位
% WN.bin;
% y = fi(y,1,24,8,fm);
% fix_WN = WN*2^8;
%% 测试数据大小用
WN1 = exp(-1i*2*pi/N);
temp = zeros(1,N);
temp_re = zeros(1,N);
temp_im = zeros(1,N);
result = zeros(1,N);
%% -----------------------------
for L=1:M
    B=bitshift(1,L-1);%第L级中，每个蝶形的两个输入数据相距B个点，每级有B个不同的旋转因子
    for J = 0:B-1 % J代表了不同的旋转因子
        %         p=J*2^(M-L);% 旋转因子增量
        p = bitshift(J,M-L);
        WNp = TWFa^p;
        WNp = fi(WNp,1,24,8,fm);
        for k = J+1:2^L:N % 本次蝶形运算的跨越间隔为2^L
            kp=k+B; % 蝶形运算的两个因子对应单元下标的关系
            t = y(kp)*WNp; % 蝶形运算的乘积项
            t = fi(t,1,24,8,fm);
            y(kp) = y(k)-t; % 蝶形运算， 先进行减法运算，然后进行加法运算，否则要使用中间变量来传递y(k)
            y(k) = y(k)+t; % 蝶形运算
        end
    end
end
%% -----------------------------
y = abs(y);
y1=abs(fft(x)); %结果对比
i = 1 : N;
subplot(2,1,1);plot(i,y1);title('fft');
subplot(2,1,2);plot(i,y);title('my-fft')