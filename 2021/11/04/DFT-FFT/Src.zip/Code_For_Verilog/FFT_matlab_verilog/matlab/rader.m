function [outputArg1] = rader(xk,N)
    j = 0;
    for i=1:N%这里实现了奇偶前后分开排序 , %比较前半部分序数【0 1 2 3 】，对每对中的后一个偶数进行交换1换4,3换6 
    if i<j 
        t=xk(j+1); 
        xk(j+1)=xk(i);%交换 
        xk(i)=t; 
    end %求下一个倒序数 
    k=bitshift(N,-1);%数组半长 
    while(j>=k)%j为下一个倒序数，比较100的最高位1，如果为1，置0 
        j=j-k;
        k=bitshift(k,-1);%变为010，准备比较第二位的1，循环 
        if(k==0)
            break;
        end
%       k = k/2
    end
    j=j+k;%找到为0 的一位，补成1，j就是下一个倒序数 
    end
    outputArg1 = xk;
end