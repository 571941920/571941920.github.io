function [outputArg1] = get_fimath()
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵�� 
fm=fimath('RoundingMethod','Floor','OverflowAction','Saturate','ProductMode'...
,'SpecifyPrecision');
fm.ProductWordLength = 48;
fm.ProductFractionLength = 16;
fm.SumMode = 'SpecifyPrecision';
fm.SumWordLength = 25;
fm.SumFractionLength = 8;

outputArg1 = fm;

end

