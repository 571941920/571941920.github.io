clear all;close all;clc;
%=======================================================
% Wnr calcuting
%=======================================================
N = 128;
for r = 0:63
    Wnr_factor  = cos(2*pi*r/N) - 1i*sin(2*pi*r/N);
%     Wnr_factor = exp(-1i*pi/r);
    Wnr_integer = floor(Wnr_factor * 2^13);
   
    if (real(Wnr_integer)<0)
        Wnr_real    = real(Wnr_integer) + 2^16;  %�����Ĳ���
    else
        Wnr_real    = real(Wnr_integer); 
    end
    if (imag(Wnr_integer)<0)
        Wnr_imag    = imag(Wnr_integer) + 2^16; 
    else
        Wnr_imag    = imag(Wnr_integer);
    end
   
%     Wnr(2*r+1,:)  =  dec2hex(Wnr_real)   %ʵ��
%     Wnr(2*r+2,:)  =  dec2hex(Wnr_imag)   %�鲿
 Wnr_real_r(r+1,:)  =  Wnr_real;
 Wnr_imag_r(r+1,:)  =  Wnr_imag;
end